package edu.CSUSM.testTaker.UI.Pages;

import java.awt.image.BufferedImage;

import edu.CSUSM.testTaker.UI.CustomPage;
import edu.CSUSM.testTaker.UI.CustomPage.PanelType;

public class CourseList extends CustomPage {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public CourseList(String panelName, PanelType currentPanelType) {
		super(panelName, currentPanelType);
		// TODO Auto-generated constructor stub
		// System.out.println("Printing a new Form");
		updateActions();
	}

	public CourseList(String panelName, PanelType currentPanelType, BufferedImage newImage) {
		super(panelName, currentPanelType, newImage);
		// TODO Auto-generated constructor stub
		updateActions();
	}

	public CourseList(String panelName, PanelType currentPanelType, String imageAddress) {
		super(panelName, currentPanelType, imageAddress);
		// TODO Auto-generated constructor stub
		updateActions();
	}

	public void updateActions() {

		// Set the button names
		setButtonNames(new String[] { "Course Management", "Other 1"});

		for (int i = 0; i < this.currentActions.length; i++) {
			switch (i) {
			case 0:
				
				break;
			case 1:
				
				break;
			case 2:
				
				break;
			default:
				System.out.println("Not enough implemented classes");
				break;
			}
		}
	}
}
